const express = require('express');
const bodyParser = require('body-parser');
const clientesRoutes = require('./routes/clientes');
const telefonesRoutes = require('./routes/telefones');
const carrosRoutes = require('./routes/carros');

const app = express();
const port = 3000;

app.use(bodyParser.json());

app.use('/clientes', clientesRoutes);
app.use('/telefones', telefonesRoutes);
app.use('/carros', carrosRoutes);

app.listen(port, () => {
    console.log(`API rodando na porta ${port}`);
});