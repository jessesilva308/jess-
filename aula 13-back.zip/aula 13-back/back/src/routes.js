const express = require('express')
const router = express.Router();

const clientes = require('./controller/controllerclientes')
const professores = require('./controller/controllerprofessores')
const telefone = require('./controller/controllertelefone')
const veiculos = require('./controller/controllerveiculos')

const teste = (req, res) => {
    res.json("Back-end, respondendo com sucesso")
}

router.get('/', teste)

router.post('/clientes', clientes.create) 
router.get('/clientes', clientes.read) 
router.put('/clientes/:id', clientes.update) 
router.delete('/clientes/:id', clientes.deletar)

router.post('/professores', professores.create) 
router.get('/professores', professores.read) 
router.put('/professores/:id', professores.update) 
router.delete('/professores/:id', professores.deletar)

router.post('/telefone', telefone.create) 
router.get('/telefone', telefone.read) 
router.put('/telefone/:id', telefone.update) 
router.delete('/telefone/:id', telefone.deletar)

router.post('/veiculos', veiculos.create) 
router.get('/veiculos', veiculos.read) 
router.put('/veiculos/:id', veiculos.update) 
router.delete('/veiculos/:id', veiculos.deletar)

module.exports = router